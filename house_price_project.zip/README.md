# House Price Prediction
Simple regression model using Python and Scikit-learn.
